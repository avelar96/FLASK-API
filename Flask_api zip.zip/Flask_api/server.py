
import re
from flask import Flask, abort, render_template, request
from moc_data import mock_data
import json

app = Flask(__name__)
coupon_codes= [
    {
        "code": "qwerty",
        "discount": 10
    }
]

me = {
    "name": "Martin",
    "last": "Avelar",
    "age": 35,
    "hobbies": [],
    "email": "abc@gmail.com",
    "address": {
        "street": "Evergreen",
        "city": "Springfield",
    }
}


@app.route("/")
@app.route("/home")
def home():
    return render_template("index.html")

@app.route("/test")
def test():
    return "Hello there!"

# / about
@app.route("/about")
def about():
    #return full name
    return me["name"] + " " + me["last"]
    

# / about email
@app.route("/about/email")
def email():
    return me["email"]

#/ about address
@app.route("/about/address")
def address():
    return me["address"]



#####API#####



@app.route("/api/catalog", methods=["get"])
def get_catalog():
    #returns catalog as JSON
    return json.dumps(mock_data)

@app.route("/api/catalog", methods=["post"])
def save_product():
    # get request payload (body)
    product = request.get_json()

    #validate that title exists in dict,if not abort(404)
    if not 'title' in product or len(product["title"]) < 5:
        return abort(400, "Title is required, and should contain at least 5 char") #400 = bad request
    
    #validate that price exist and is greater than 0
    if not 'price' in product:
        return abort(400, "Price is required")

    if not isinstance(product["price"], float) and not isinstance(product["price"],int):
        return abort(400, "Price should a valid float number")

    if product['price'] <= 0:
        return abort(400,"Price should be greater than 0")

    #save the product
    mock_data.append(product)
    product["_id"] = len(product["title"])

    #return the saved object
    return json.dumps(product)

@app.route("/api/categories")
def get_categories():
    #return the list (string) of unique categories
    categories = []
    for prod in mock_data:
        print(prod["category"])
        if not prod["category"] in categories:
            categories.append(prod["category"])

    return json.dumps(categories)


@app.route("/api/product/<id>")
def get_product(id):
    for prod in mock_data:
        if prod["_id"] == id:
            #found it
            return prod

    return abort(404) # 404 = not found



# /api/catalog<category>
#return all the products that belong to that cat
@app.route("/api/catalog/<category>")
def get_by_category(category):
    result = []
    for prod in mock_data:
        if prod["category"].lower == category.lower():
            result.append(prod)
    
    return json.dumps(result)


# /api/cheapest
# cheapest product

@app.route("/api/cheapest")
def cheapest_product():
    pivot = mock_data[0]
    for prod in mock_data:
        #if prod price is lower than pivot price
        # pivot = prod
        if prod["price"] < pivot["price"]:
            pivot = prod

    return pivot


###coupon codes###

#Post to /api/couponCodes
@app.route("/api/couponCodes")
def save_coupon():
    coupon = request.get_json()

    #validation

    #save
    coupon_codes.append(coupon)
    coupon["_id"] = coupon["code"]
    return json.dumps(coupon)
#GET to /api/couponCodes
@app.route("/api/couponCodes")
def get_coupons():
    return json.dumps(coupon_codes)

#get coupon by its code or 404
@app.route("/api/couponCodes/<code>")
def get_coupon_by_code(code):
    for coupon in coupon_codes:
        if(coupon["code"] == code):
            return json.dumps(coupon)

    return abort(404)
    
#start the application
#debug true
app.run(debug=True)